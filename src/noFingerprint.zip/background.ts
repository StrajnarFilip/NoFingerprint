const ALL_URLS = "<all_urls>"

function BeforeRequestCallback(
    details: browser.webRequest._OnBeforeRequestDetails
): void {
    
}

browser.webRequest.onBeforeRequest.addListener(
    BeforeRequestCallback,
    { urls: [ALL_URLS] },
    ["blocking"]
);

function ModifyResponseId(requestId: string) {
    const filter = browser.webRequest.filterResponseData(requestId);
    const decoder = new TextDecoder("utf-8");
    const encoder = new TextEncoder();

    filter.ondata = event => {
        const decodedBody: string = decoder.decode(event.data, { stream: true });

        const cssMediaRemoved = decodedBody.replaceAll("@media", '');
        const cssDocumentRemoved = cssMediaRemoved.replaceAll("@document", '');
        const cssSupportsRemoved = cssDocumentRemoved.replaceAll("@supports", '');
        const cssImportRemoved = cssSupportsRemoved.replaceAll("@import", '');
        const cssFontFaceRemoved = cssImportRemoved.replaceAll("@font-face", '');
        const cssFontFamilyRemoved = cssFontFaceRemoved.replaceAll("font-family:",'')

        filter.write(encoder.encode(cssFontFamilyRemoved));
        filter.disconnect();
    }
}

function BeforeHeadersCallback(
    details: browser.webRequest._OnBeforeSendHeadersDetails
): browser.webRequest.BlockingResponse { 

    if (details.requestHeaders) {
        const isRequestFont = details.requestHeaders.some(
            (element, elIndex) => {
                return element.name.toLowerCase().includes("sec-fetch-dest") && element.value?.toLowerCase().includes("font")
            }
        )

        const isRequestHtml = details.requestHeaders.some(
            (element, elIndex) => {
                return element.name.toLowerCase().includes("accept") && element.value?.toLowerCase().includes("text/html")
            }
        )

        if (isRequestHtml) {
            ModifyResponseId(details.requestId)
        }

        return {
            cancel: isRequestFont
        }
    }

    return {

    }
}

browser.webRequest.onBeforeSendHeaders.addListener(
    BeforeHeadersCallback,
    { urls: [ALL_URLS] },
    ["blocking", "requestHeaders"]
)